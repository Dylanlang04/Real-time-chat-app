===Affidavit Statement===
"I attest that I am the sole author of this submitted work and any code borrowed from other sources has been identified by comments placed in my submitted code. Dylan Langlois, 101295110"

===INSTALL INSTRUCTIONS===
1. Navigate to the project directory using the cd command.
2. Run the command "npm install", or "npm install socket.io"

===LAUNCH INSTRUCTIONS===
1. Open a terminal and navigate to the project directory with the server.js file by using the cd command, Ex: cd Desktop/A3.
2. Execute the following command to launch the app: node server.js

===TESTING INSTRUCTIONS===
1. To test the server, open your prefered browser and visit the following URL on multiple tabs: http://localhost:3000/index.html

===VIDEO DEMONSTRATION===
does not apply to this assignment